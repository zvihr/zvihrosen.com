% Homework 1 Problem 2
x = 0:0.01:3*pi/2;
cosx = 1 - x.^2/factorial(2) + x.^4/factorial(4) - x.^6/factorial(6) + x.^8/factorial(8);
plot(x,cosx);
axis([0 3*pi/2 -1.3 1.3]);
title('Maclaurin Series Cosine Approximation');

% Creates vector of x values, plugs those values into the Maclaurin Series
% function, plots the data, sets the viewing window, and titles the plot