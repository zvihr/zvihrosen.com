% Homework 1 Problem 3
function [r,theta] = cartesian2polar(x,y)
r = norm([x,y]);
if x > 0
    theta = atan(y/x);
elseif x < 0
    if y > 0
        theta = atan(y/x)+pi;
    elseif y < 0
        theta = atan(y/x)-pi;
    else
        theta = pi;
    end
else
    if y > 0
        theta = pi/2;
    elseif y < 0
        theta = -pi/2;
    else
        theta = 0;
    end
end
return

% Uses if statements to sort through the various cases of x and y, applying
% the appropriate conversion function for each case