a = [6 4 2; 3 2 -6; 2 -2 1; -1 0 0];
b = [2 6 4; 4 -3 1; 4 2 -4; 0 -1 0];
length = size(a);
length = length(1);

for n = 1:length
    [theta, c, cmag] = dotncross(a(n,:),b(n,:));
    fprintf('a: %d %d %d, b: %d %d %d, theta: %0.2f, c: %d %d %d, cmag: %0.2f\n', ...
        a(n,1), a(n,2), a(n,3), b(n,1), b(n,2), b(n,3), theta, c(1), c(2), c(3), cmag);
end