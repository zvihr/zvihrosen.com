% Homework 1 Problem 4
function [theta, c, cmag] = dotncross(a,b)
% dotncross
% Finds theta using a dot product
% Crosses the vectors and plots the output, setting the viewing position
% Outputs the angle of separation, the cross product vector output, and
% the magnitude of that vector
theta = acos(a * b' / (norm(a)*norm(b)));
c = cross(a,b);
cmag = norm(c);
figure
hold on
quiver3(0,0,0,a(1),a(2),a(3),'--r');
quiver3(0,0,0,b(1),b(2),b(3),'--m');
quiver3(0,0,0,c(1),c(2),c(3),'-b');
view(45,15)
title('Visualization of Original and Crossed Vectors');
hold off

