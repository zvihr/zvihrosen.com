x = [2,2,0,-3,-2,-1,0,0,2];
y = [0,1,3,1,0,-2,0,-2,2];

for n=1:length(x)
    [r,theta] = cartesian2polar(x(n),y(n));
    fprintf('x: %0.0f, y: %0.0f, r: %0.2f, theta: %0.2f\n',x(n),y(n),r,theta);
end