% Homework 1 Problem 1
T = 32:3.6:93;
T = 5/9*(T-32);
rho = 5.5289*10^-8 * T.^3 - 8.5016*10^-6 * T.^2 + 6.5622*10^-5 * T + 0.99987;
plot(T,rho);

% Creates vector, converts to celcius, puts vector through function
% to generate vector of outputs, plots the data